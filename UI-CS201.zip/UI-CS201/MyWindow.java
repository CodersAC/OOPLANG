
/**
 * Write a description of class MyWindow here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import javax.swing.*;
public class MyWindow
{
    public static void main(String[] args){
        JFrame window = new JFrame();
        window.setTitle("Carlo G. Quilla  CS-201");
        window.setLocation(0,0);
        window.setBounds(600,250,600,400);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setVisible(true);
    }
}

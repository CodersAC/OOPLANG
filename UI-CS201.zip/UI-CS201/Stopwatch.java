
/**
 * Write a description of class Stopwatch here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class Stopwatch extends JFrame
{
    //Buttons
    JButton startButton = new JButton();
    JButton stopButton = new JButton();
    JButton exitButton = new JButton();
    
    JButton okButton = new JButton();
    JButton exit2Button = new JButton();
    //Labels
    JLabel startLabel = new JLabel();
    JLabel stopLabel = new JLabel();
    JLabel elapsedLabel = new JLabel();
    //TextFields
    JTextField startTextField = new JTextField();
    JTextField stopTextField = new JTextField();
    JTextField elapsedTextField = new JTextField();
    
    long startTime;
    long stopTime;
    double elapsedTime;
    public Stopwatch(){
        setTitle("Stopwatch Application");
        
        addWindowListener(new WindowAdapter(){
            public void windowClosing(WindowEvent e){
                exitForm(e);
            }
        });
        //Get the JFrame and set Layout
        getContentPane().setLayout(new GridBagLayout());
        
        //grid x and y axis
        GridBagConstraints gridConstraints = new GridBagConstraints();
        
        startButton.setText("Start Timer");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        getContentPane().add(startButton,gridConstraints); 
        
        startButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                startButtonActionPerformed(e);
            }
            
        });
        
        stopButton.setText("Stop Timer");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;
        getContentPane().add(stopButton,gridConstraints); 
        
        stopButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                stopButtonActionPerformed(e);
            }
            
        });
        
        exitButton.setText("Exit Timer");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 2;
        getContentPane().add(exitButton,gridConstraints); 
        
        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                exitButtonActionPerformed(e);
            }
            
        });
         
        startLabel.setText("Start Timer");
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 0;
        getContentPane().add(startLabel,gridConstraints); 
        
        stopLabel.setText("Stop Timer");
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 1;
        getContentPane().add(stopLabel,gridConstraints);
        
        elapsedLabel.setText("Elapsed Timer (sec)");
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 2;
        getContentPane().add(elapsedLabel,gridConstraints);
        
        startTextField.setText("");
        startTextField.setColumns(15);
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 0;
        getContentPane().add(startTextField,gridConstraints); 
        
        stopTextField.setText("");
        stopTextField.setColumns(15);
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 1;
        getContentPane().add(stopTextField,gridConstraints);
        
        elapsedTextField.setText("");
        elapsedTextField.setColumns(15);
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 2;
        getContentPane().add(elapsedTextField,gridConstraints);
        pack();
        //setSize(300,100);

    }
    
    private void exitForm(WindowEvent e){
        JFrame f;
        f = new JFrame();
        JOptionPane.showMessageDialog(f, "Exiting Module");
        //System.exit(0);
    }
    
    private void  startButtonActionPerformed(ActionEvent e){
        
        JFrame f;
        f = new JFrame();
        JOptionPane.showMessageDialog(f, "Start Timer Initiated");
        
    }
    
    private void  stopButtonActionPerformed(ActionEvent e){
        
        JFrame f;
        f = new JFrame();
        JOptionPane.showMessageDialog(f, "Stop Timer Initiated");
        
    }

    private void  exitButtonActionPerformed(ActionEvent e){
        
        JFrame f;
        f = new JFrame();
        JOptionPane.showMessageDialog(f, "Exit Timer");
        System.exit(0);
    }
    public static void main(String[] args){
        new Stopwatch().show();
    }
}


/**
 * Write a description of class Stopwatch here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.awt.*;
import javax.swing.*;
public class test {

    public static void main(String[] args){
        JFrame Frame = new JFrame("Stopwatch Application");
        //Buttons
        JButton startButton = new JButton();
        JButton stopButton = new JButton();
        JButton exitButton = new JButton();
        //Labels
        JLabel startLabel = new JLabel();
        JLabel stopLabel = new JLabel();
        JLabel elapsedLabel = new JLabel();
        //TextFields
        JTextField startTextField = new JTextField();
        JTextField stopTextField = new JTextField();
        JTextField elapsedTextField = new JTextField();
        //Get the JFrame and set Layout
        Frame.setLayout(new GridBagLayout());
        
        //grid x and y axis
        GridBagConstraints gridConstraints = new GridBagConstraints();
        
        startButton.setText("Start Timer");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        Frame.add(startButton,gridConstraints); 
        
        stopButton.setText("Stop Timer");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;
        Frame.add(stopButton,gridConstraints); 
        
        exitButton.setText("Exit Timer");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 2;
        Frame.add(exitButton,gridConstraints); 
        
        startLabel.setText("Start Timer");
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 0;
        Frame.add(startLabel,gridConstraints); 
        
        stopLabel.setText("Stop Timer");
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 1;
        Frame.add(stopLabel,gridConstraints);
        
        elapsedLabel.setText("Elapsed Timer (sec)");
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 2;
        Frame.add(elapsedLabel,gridConstraints);
        
        startTextField.setText("Start Timer");
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 0;
        Frame.add(startTextField,gridConstraints); 
        
        stopTextField.setText("Stop Timer");
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 1;
        Frame.add(stopTextField,gridConstraints);
        /*
        okButton.setText("OK");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 3;
        getContentPane().add(okButton,gridConstraints); 
        
        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                okButtonActionPerformed(e);
            }
            
        });
        
        exit2Button.setText("EXIT");
        gridConstraints.gridx = 3;
        gridConstraints.gridy = 3;
        getContentPane().add(exit2Button,gridConstraints); 
        
        exit2Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                exit2ButtonActionPerformed(e);
            }
            
        });*/
        
        elapsedTextField.setText("Elapsed Timer (sec)");
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 2;
        Frame.add(elapsedTextField,gridConstraints);
        Frame.pack();
        Frame.setVisible(true);
    }
}


/**
 * Write a description of class MyFrame here.
 *
 * @author (Carlo G. Quilla)
 * @version (Sept 21, 2022)
 */
import javax.swing.*;
public class MyFrame extends JFrame
{
    public static void main(String[] args){
        new MyFrame();
    }
    
    public MyFrame(){
        setSize(640,400);
        setLocation(0,0);
        setTitle("Carlo G. Quilla CS-201");
        setVisible(true);
    }
}

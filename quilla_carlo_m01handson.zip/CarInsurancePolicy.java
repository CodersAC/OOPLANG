
/**
 * Write a description of class CarInsurancePolicy here.
 *
 * @author (Carlo G. Quilla)
 * @version (September 07, 2022)
 */
public class CarInsurancePolicy
{
    public static void main(String[] args){
        int policyNumber = 2003;
        int numPayments = 10;
        String cityofresidence = "Angeles City";
        CarPolicy(policyNumber,numPayments,cityofresidence);
        CarPolicy(policyNumber,numPayments);
        CarPolicy(policyNumber);
    }
    public static void CarPolicy(int policyNumber,int numPayments,String cityofresidence){
        System.out.println("Policy Number :" +policyNumber);
        System.out.println("Number of Payments:" +numPayments);
        System.out.println("City of Residence :" +cityofresidence);
    }
    public static void CarPolicy(int policyNumber,int numPayment){
        System.out.println("\nPolicy Number : "+policyNumber);
        System.out.println("Number of Payments : "+numPayment);
    }
    public static void CarPolicy(int policyNumber){
        System.out.println("\nPolicy Numer : "+policyNumber);
    }
    
}

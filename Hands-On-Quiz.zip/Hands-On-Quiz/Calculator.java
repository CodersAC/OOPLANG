
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Calculator extends JFrame 
{
    JLabel operand1 = new JLabel("Number 1: ");
    JLabel operator = new JLabel("Operation: ");
    JLabel operand2 = new JLabel("Number 2:");
    JLabel result = new JLabel("Result: ");
    
    JButton calculateB = new JButton("Calculate");
    JButton exitB = new JButton("Exit");
    
    JTextField textField1 = new JTextField();
    JTextField textField2 = new JTextField();
    JTextField textField3 = new JTextField();
    JTextField textField4 = new JTextField();
    
    
    public Calculator(){ 
        setTitle("Simple Calculator");
        
        getContentPane().setLayout(new GridBagLayout());
        
        GridBagConstraints constraints = new GridBagConstraints();
        
        constraints.gridx = 1;
        constraints.gridy = 2;
        getContentPane().add(operand1,constraints);
        
        constraints.gridx = 1;
        constraints.gridy = 4;
        getContentPane().add(operator,constraints);
        
        constraints.gridx = 1;
        constraints.gridy = 6;
        getContentPane().add(operand2,constraints);
        
        constraints.gridx = 1;
        constraints.gridy = 8;
        getContentPane().add(result,constraints);
        
        constraints.gridx = 1;
        constraints.gridy = 10;
        getContentPane().add(calculateB,constraints);
        
        calculateB.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                calculateActionPerformed(e);
        }
        });
        
        textField1.setColumns(10);
        constraints.gridx = 2;
        constraints.gridy = 2;
        getContentPane().add(textField1,constraints);
        
        textField2.setColumns(5);
        constraints.gridx = 2;
        constraints.gridy = 4;
        getContentPane().add(textField2,constraints);
        
        textField3.setColumns(10);
        constraints.gridx = 2;
        constraints.gridy = 6;
        getContentPane().add(textField3,constraints);
        
        textField4.setColumns(10);
        constraints.gridx = 2;
        constraints.gridy = 8;
        getContentPane().add(textField4,constraints);
        
        constraints.gridx = 2;
        constraints.gridy = 10;
        getContentPane().add(exitB,constraints);
        
        exitB.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                exitActionPerformed(e);
        }
        });
        
        pack();
         
    }
    private void calculateActionPerformed(ActionEvent e){
        double num1 = Double.parseDouble(textField1.getText());
        String opr = textField2.getText();
        double num2 = Double.parseDouble(textField3.getText());
        
        if(opr.equals("*")){
            double reslt = num1 * num2;
            textField4.setText(Double.toString(reslt));
        }
        if(opr.equals("/")){
            double reslt = num1 / num2;
            textField4.setText(Double.toString(reslt));
        }
        if(opr.equals("+")){
            double reslt = num1 + num2;
            textField4.setText(Double.toString(reslt));
        }
        if(opr.equals("-")){
            double reslt = num1 - num2;
            textField4.setText(Double.toString(reslt));
        }
        
    }
    
    private void exitActionPerformed(ActionEvent e){
        JOptionPane.showMessageDialog(null,"Thank you for Using ");
        System.exit(0);
    }
    public static void main(String[] args){
        new Calculator().show();
    }
}

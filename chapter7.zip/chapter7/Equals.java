
/**
 * Write a description of class TryToCompareString here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

public class Equals
{
    public static void main(String[] args){
        String myString = "Hello";
        //char result = myString.charAt(4);
        boolean result = myString.endsWith("o");
        boolean result2 = myString.startsWith("H");
        System.out.println(myString.replace("l","o"));
        System.out.println(result + " " +result2);
        
        /*String myString = "Welcome to Holy Angel";
        System.out.println(myString.indexOf("Holy"));*/
        
        /*String aName = "Dog Bark";
        String anotherName = "Dog Bark";
        String myString = "Welcome to Holy Angel";
        System.out.println(aName.toUpperCase() + " Upper " + anotherName.toUpperCase()); 
        System.out.println(aName.toLowerCase() + " Lower " + anotherName.toLowerCase());
        System.out.println(aName.length() + " Lenght " + anotherName.length());*/
        
        /*if (aName.equals(anotherName))
            System.out.print(aName + " equals E " + anotherName);  
        if (aName.equalsIgnoreCase(anotherName))
            System.out.print(aName + " equals EIC " + anotherName); 
        else
            System.out.print(aName + " does not equal " + anotherName);*/
    }
}

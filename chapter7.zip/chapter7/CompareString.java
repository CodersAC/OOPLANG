
/**
 * Write a description of class TryToCompareString here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class CompareString
{
    public static void main(String[] args){
        String aName = "Carmen";
        String anotherName;
        Scanner input = new Scanner(System.in);
        System.out.print("Enter Your Name > ");
        anotherName  = input.nextLine();
        if (aName.equals(anotherName))
            System.out.print(aName + " equals " + anotherName); 
        else if (aName.equalsIgnoreCase(anotherName))
            System.out.print(aName + " equals " + anotherName); 
        else if (aName.compareTo(anotherName)>0)
            System.out.print(aName + " equals " + anotherName); 
        else
            System.out.print(aName + " does not equal " + anotherName);
    }
}


/**
 * Write a description of class TryToCompareString here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class TryToCompareString
{
    public static void main(String[] args){
        String aName = "Carmen";
        String anotherName;
        Scanner input = new Scanner(System.in);
        System.out.print("Enter Your Name > ");
        anotherName  = input.nextLine();
        if (aName == anotherName)
            System.out.print(aName + " equals " + anotherName); 
        else
            System.out.print(aName + " does not equal " + anotherName);
    }
}
